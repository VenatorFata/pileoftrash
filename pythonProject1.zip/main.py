from flask import Flask, url_for

app = Flask(__name__)

@app.route('/')
def mission_name():
    return f'''<!doctype html>
                 <html lang="en">
                  <head>
                   <meta charset="utf-8">
                   <title>Миссия на Марс</title>
                  </head>
                  <body>
                   <h1>Миссия Колонизация Марса</h1>
                  </body>
                 </html>'''
@app.route('/index')
def index():
    return f'''<!doctype html>
             <html lang="en">
              <head>
               <meta charset="utf-8">
               <title>Миссия на Марс</title>
              </head>
              <body>
               <h1>И на Марсе будут яблони цвести!</h1>
              </body>
             </html>'''
@app.route('/promotion')
def promotion():
    return f'''<!doctype html>
             <html lang="en">
              <head>
               <meta charset="utf-8">
               <title>Миссия на Марс</title>
              </head>
              <body>
               <text><font size="18" face="Arial" color="#d12312">Человечество вырастает из детства.<br><br>
                     Человечеству мала одна планета.<br><br>
                     Мы сделаем обитаемыми безжизненные пока планеты.<br><br>
                     И начнем с Марса!<br><br>
                     Присоединяйся!</font></text>
              </body>
             </html>'''
@app.route('/image_mars')
def image_mars():
    return f'''<!doctype html>
             <html lang="en">
              <head>
               <meta charset="utf-8">
               <title>Миссия на Марс</title>
              </head>
              <body><img src="{url_for('static', filename='img/MARS.png')}" 
           alt="у вас марс украли (батончик)">
              </body>
             </html>'''

if __name__ == '__main__':
        app.run(port=8080, host='127.0.0.1')